<?php
// admin/settings-page.php

function pelank_life_admin_menu() {
    add_menu_page(
        __('Pelank Life', 'pelank-life'),
        'Pelank Life',
        'manage_options',
        'pelank-life-settings',
        'pelank_life_render_settings_page',
        'dashicons-heart',
        65
    );
}
add_action('admin_menu', 'pelank_life_admin_menu');

function pelank_life_render_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Pelank Life Settings', 'pelank-life'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('pelank_life_settings');
            do_settings_sections('pelank_life_settings');
            submit_button();
            ?>
        </form>
        <hr>
        <h2><?php _e('Available Calculators:', 'pelank-life'); ?></h2>
        <ul>
            <?php
            $modules_dir = PELANK_LIFE_PATH . 'modules/';
            foreach (glob($modules_dir . '*/', GLOB_ONLYDIR) as $module_dir) {
                $slug = basename($module_dir);
                echo "<li><strong>" . esc_html(ucfirst($slug)) . "</strong></li>";
            }
            ?>
        </ul>
    </div>
    <?php
}

// تنظیمات پایه (در آینده قابل گسترش برای فعال/غیرفعال‌سازی ماژول‌ها)
function pelank_life_register_settings() {
    register_setting('pelank_life_settings', 'pelank_life_options');
    add_settings_section('pelank_life_main', __('General Settings', 'pelank-life'), null, 'pelank_life_settings');
}
add_action('admin_init', 'pelank_life_register_settings');
