<?php
$locale = get_locale();
if (!file_exists(__DIR__ . "/lang/{$locale}.php")) $locale = 'en_US';
$bmi_strings = include(__DIR__ . "/lang/{$locale}.php");
?>
<div id="pelank-bmi-widget">
  <div class="pl-bmi-card">
    <!-- Heading -->
    <div class="pl-bmi-header-box">
    <h2 class="pl-bmi-heading"><?php echo $bmi_strings['bmi_calculator']; ?></h2>
    <p class="pl-bmi-description"><?php echo $bmi_strings['bmi_description']; ?></p>
    </div>
    <!-- Tabs -->
    <div class="pl-bmi-tabs">
      <button type="button" class="pl-bmi-tab-btn active" data-tab="adult"><?php echo $bmi_strings['tab_adult']; ?></button>
      <button type="button" class="pl-bmi-tab-btn" data-tab="child"><?php echo $bmi_strings['tab_child']; ?></button>
    </div>

    <!-- Form: Adult -->
    <form id="pl-bmi-form-adult" class="pl-bmi-form-tab" autocomplete="off">
      <div class="pl-bmi-row">
        <label><?php echo $bmi_strings['weight']; ?>
          <input type="number" id="pl-bmi-weight-adult" min="1" step="0.1" required>
          <select id="pl-bmi-weight-unit-adult">
              <option value="kg"><?php echo $bmi_strings['unit_kg']; ?></option>
              <option value="lb"><?php echo $bmi_strings['unit_lb']; ?></option>
          </select>
        </label>
        <label><?php echo $bmi_strings['height']; ?>
          <input type="number" id="pl-bmi-height-adult" min="1" step="0.1" required>
          <select id="pl-bmi-height-unit-adult">
              <option value="cm"><?php echo $bmi_strings['unit_cm']; ?></option>
              <option value="in"><?php echo $bmi_strings['unit_in']; ?></option>
          </select>
        </label>
      </div>
      <div class="pl-bmi-center">
        <button type="submit" class="pl-main-btn"><?php echo $bmi_strings['calculate']; ?></button>
        <button type="button" class="pl-secondary-btn"><?php echo $bmi_strings['reset']; ?></button>
      </div>
    </form>

    <!-- Form: Child/Teen -->
    <form id="pl-bmi-form-child" class="pl-bmi-form-tab" style="display:none" autocomplete="off">
      <div class="pl-bmi-row">
        <label><?php echo $bmi_strings['weight']; ?>
          <input type="number" id="pl-bmi-weight-child" min="1" step="0.1" required>
          <select id="pl-bmi-weight-unit-child">
              <option value="kg"><?php echo $bmi_strings['unit_kg']; ?></option>
              <option value="lb"><?php echo $bmi_strings['unit_lb']; ?></option>
          </select>
        </label>
        <label><?php echo $bmi_strings['height']; ?>
          <input type="number" id="pl-bmi-height-child" min="1" step="0.1" required>
          <select id="pl-bmi-height-unit-child">
              <option value="cm"><?php echo $bmi_strings['unit_cm']; ?></option>
              <option value="in"><?php echo $bmi_strings['unit_in']; ?></option>
          </select>
        </label>
      </div>
      <div class="pl-bmi-row">
        <label><?php echo $bmi_strings['age']; ?>
          <input type="number" id="pl-bmi-age-child" min="2" max="18" required>
        </label>
        <label><?php echo $bmi_strings['gender']; ?>
          <select id="pl-bmi-gender-child">
              <option value="male"><?php echo $bmi_strings['male']; ?></option>
              <option value="female"><?php echo $bmi_strings['female']; ?></option>
          </select>
        </label>
      </div>
      <div class="pl-bmi-center">
        <button type="submit" class="pl-main-btn"><?php echo $bmi_strings['calculate']; ?></button>
        <button type="button" class="pl-secondary-btn"><?php echo $bmi_strings['reset']; ?></button>
      </div>
    </form>
    <div class="pl-bmi-divider"></div>
    <!-- Result area (only shows after calculation) -->
    <div class="pl-bmi-result-area" style="display:none;">
      <!-- Dynamic content (BMI box, advice, table, actions, signature) comes here by JS -->
    </div>
  </div>
</div>

<!-- JS translations -->
<script>
window.plBmiStrings = <?php echo json_encode($bmi_strings, JSON_UNESCAPED_UNICODE); ?>;
</script>
<script src="/path/to/bmi.js"></script>
