document.addEventListener('DOMContentLoaded', function(){

  // --- داده percentile برای مثال (در آینده گسترش بده) ---
  const bmiPercentileData = {
    male: {
      5:  { p5: 13.8, p85: 17.4, p95: 18.9 },
      10: { p5: 14.0, p85: 19.7, p95: 22.2 },
      15: { p5: 16.4, p85: 24.1, p95: 28.1 },
      18: { p5: 18.2, p85: 25.4, p95: 29.5 }
    },
    female: {
      5:  { p5: 13.6, p85: 17.2, p95: 18.7 },
      10: { p5: 14.1, p85: 19.3, p95: 22.2 },
      15: { p5: 16.6, p85: 24.1, p95: 28.2 },
      18: { p5: 17.7, p85: 25.0, p95: 29.2 }
    }
  };

  // تب ها
  document.querySelectorAll('#pelank-bmi-widget .pl-bmi-tab-btn').forEach(function(btn){
    btn.addEventListener('click', function(){
      document.querySelectorAll('#pelank-bmi-widget .pl-bmi-tab-btn').forEach(e=>e.classList.remove('active'));
      btn.classList.add('active');
      let tab = btn.getAttribute('data-tab');
      document.querySelectorAll('#pelank-bmi-widget .pl-bmi-form-tab').forEach(f=>f.style.display='none');
      document.querySelector('#pelank-bmi-widget #pl-bmi-form-' + tab).style.display = '';
      clearAllResults();
    });
  });

  // دکمه ریست فرم
  document.querySelectorAll('#pelank-bmi-widget .pl-secondary-btn').forEach(function(btn){
    btn.addEventListener('click', function(e){
      let form = btn.closest('form');
      form.reset();
      clearAllResults();
    });
  });

  function clearAllResults() {
    let area = document.querySelector('#pelank-bmi-widget .pl-bmi-result-area');
    area.style.display = 'none';
    area.innerHTML = '';
  }

  // فرم بزرگسال
  document.querySelector('#pelank-bmi-widget #pl-bmi-form-adult').addEventListener('submit', function(e){
    e.preventDefault();
    let weight = parseFloat(document.getElementById('pl-bmi-weight-adult').value);
    let weightUnit = document.getElementById('pl-bmi-weight-unit-adult').value;
    let height = parseFloat(document.getElementById('pl-bmi-height-adult').value);
    let heightUnit = document.getElementById('pl-bmi-height-unit-adult').value;

    if (weightUnit === 'lb') weight *= 0.45359237;
    if (heightUnit === 'in') height *= 2.54;
    let heightM = height / 100;
    let bmi = weight / (heightM * heightM);

    let rows = [
      { label: plBmiStrings['underweight'], range: '<18.5',    check: (bmi<18.5) },
      { label: plBmiStrings['normal'],      range: '18.5–24.9', check: (bmi>=18.5 && bmi<25) },
      { label: plBmiStrings['overweight'],  range: '25–29.9',   check: (bmi>=25 && bmi<30) },
      { label: plBmiStrings['obesity_1'],   range: '30–34.9',   check: (bmi>=30 && bmi<35) },
      { label: plBmiStrings['obesity_2'],   range: '35–39.9',   check: (bmi>=35 && bmi<40) },
      { label: plBmiStrings['obesity_3'],   range: '≥40',       check: (bmi>=40) }
    ];

    let resultArea = document.querySelector('#pelank-bmi-widget .pl-bmi-result-area');
    let html = '';
    let advice = '', warning = '', catIndex = -1;

    if (isNaN(bmi) || bmi <= 0) {
      html = '<div class="pl-bmi-warning-box">'+(plBmiStrings['invalid_input']||'Invalid input')+'</div>';
    } else {
      // پیدا کردن شاخص دسته برای فعال کردن ردیف
      rows.forEach((row,i)=>{ if(row.check) catIndex = i; });

      // کادر شاخص BMI
      html += `<div class="pl-bmi-bmi-box">${plBmiStrings['your_bmi']}: <b>${bmi.toFixed(2)}</b></div>`;
      // تفسیر/نکته
      if (bmi < 18.5)      { advice = plBmiStrings['advice_under']; warning = ''; }
      else if (bmi < 25)   { advice = plBmiStrings['advice_normal']; warning = ''; }
      else if (bmi < 30)   { advice = plBmiStrings['advice_over'];   warning = ''; }
      else if (bmi >= 30)  { advice = plBmiStrings['advice_obese'];  warning = plBmiStrings['warning_critical']; }
      if(advice) html += `<div class="pl-bmi-advice-box">${advice}</div>`;
      if(warning) html += `<div class="pl-bmi-warning-box">${warning}</div>`;
      // جدول دهک
      html += `<table class="pl-bmi-table"><tr><th>${plBmiStrings['category']}</th><th>BMI</th></tr>`;
      rows.forEach(function(row, i){
        html += `<tr${row.check?' class="pl-active"':''}><td>${row.label}</td><td>${row.range}${row.check?' <span class="pl-bmi-percentile">⬅️</span>':''}</td></tr>`;
      });
      html += '</table>';
      html += `<div class="pl-bmi-table-note">${plBmiStrings['bmi_table_note']}</div>`;
      // دکمه‌های اکشن
      html += `
      <div class="pl-bmi-actions">
        <button type="button" class="pl-bmi-share pl-tertiary-btn">${plBmiStrings['share']}</button>
        <button type="button" class="pl-bmi-save-pdf pl-tertiary-btn">${plBmiStrings['save_pdf']}</button>
        <button type="button" class="pl-bmi-save-img pl-tertiary-btn">${plBmiStrings['save_img']}</button>
      </div>
      `;
      // امضا
      html += `<div class="pl-bmi-signature">${plBmiStrings['signature']}</div>`;
    }
    resultArea.innerHTML = html;
    resultArea.style.display = 'block';
    bindResultActions(resultArea, 'adult');
  });

  // فرم کودک/نوجوان
  document.querySelector('#pelank-bmi-widget #pl-bmi-form-child').addEventListener('submit', function(e){
    e.preventDefault();
    let weight = parseFloat(document.getElementById('pl-bmi-weight-child').value);
    let weightUnit = document.getElementById('pl-bmi-weight-unit-child').value;
    let height = parseFloat(document.getElementById('pl-bmi-height-child').value);
    let heightUnit = document.getElementById('pl-bmi-height-unit-child').value;
    let age = parseInt(document.getElementById('pl-bmi-age-child').value);
    let gender = document.getElementById('pl-bmi-gender-child').value;

    if (weightUnit === 'lb') weight *= 0.45359237;
    if (heightUnit === 'in') height *= 2.54;
    let heightM = height / 100;
    let bmi = weight / (heightM * heightM);

    let ages = Object.keys(bmiPercentileData[gender]).map(Number);
    let closestAge = ages.reduce((prev, curr) => Math.abs(curr - age) < Math.abs(prev - age) ? curr : prev);
    let d = bmiPercentileData[gender][closestAge];

    let percentile = null, cat = '';
    if (bmi < d.p5) { percentile = '<5'; cat = plBmiStrings['p_below5']; }
    else if (bmi < d.p85) { percentile = '5-85'; cat = plBmiStrings['p_5to85']; }
    else if (bmi < d.p95) { percentile = '85-95'; cat = plBmiStrings['p_85to95']; }
    else { percentile = '>95'; cat = plBmiStrings['p_above95']; }

    let resultArea = document.querySelector('#pelank-bmi-widget .pl-bmi-result-area');
    let html = '';
    let advice = '', warning = '';
    if (isNaN(bmi) || bmi <= 0 || isNaN(age) || age < 2 || age > 18) {
      html = '<div class="pl-bmi-warning-box">'+(plBmiStrings['invalid_input']||'Invalid input')+'</div>';
    } else {
      html += `<div class="pl-bmi-bmi-box">${plBmiStrings['bmi_value']}: <b>${bmi.toFixed(2)}</b></div>`;
      // تفسیر/نکته
      if (percentile == '5-85') {
        advice = plBmiStrings['advice_child_normal'];
        warning = '';
      } else {
        advice = plBmiStrings['advice_child_other'];
        warning = '';
      }
      if(advice) html += `<div class="pl-bmi-advice-box">${advice}</div>`;
      if(warning) html += `<div class="pl-bmi-warning-box">${warning}</div>`;
      // جدول
      html += `<table class="pl-bmi-table"><tr><th>${plBmiStrings['percentile']}</th><th>BMI</th><th>${plBmiStrings['category']}</th></tr>`;
      html += `<tr${percentile=='<5'?' class="pl-active"':''}><td>&lt;5</td><td>${d.p5}</td><td>${plBmiStrings['p_below5']}</td></tr>`;
      html += `<tr${percentile=='5-85'?' class="pl-active"':''}><td>5-85</td><td>${d.p85}</td><td>${plBmiStrings['p_5to85']}</td></tr>`;
      html += `<tr${percentile=='85-95'?' class="pl-active"':''}><td>85-95</td><td>${d.p95}</td><td>${plBmiStrings['p_85to95']}</td></tr>`;
      html += `<tr${percentile=='>95'?' class="pl-active"':''}><td>&gt;95</td><td>–</td><td>${plBmiStrings['p_above95']}</td></tr>`;
      html += '</table>';
      html += `<div class="pl-bmi-table-note">${plBmiStrings['bmi_child_note']}</div>`;
      html += `<div style="margin-top:7px;"><a href="https://www.cdc.gov/growthcharts/clinical_charts.htm" target="_blank" rel="noopener">${plBmiStrings['see_growth_chart']}</a></div>`;
      // دکمه‌های اکشن
      html += `
      <div class="pl-bmi-actions">
        <button type="button" class="pl-bmi-share pl-tertiary-btn">${plBmiStrings['share']}</button>
        <button type="button" class="pl-bmi-save-pdf pl-tertiary-btn">${plBmiStrings['save_pdf']}</button>
        <button type="button" class="pl-bmi-save-img pl-tertiary-btn">${plBmiStrings['save_img']}</button>
      </div>
      `;
      // امضا
      html += `<div class="pl-bmi-signature">${plBmiStrings['signature']}</div>`;
    }
    resultArea.innerHTML = html;
    resultArea.style.display = 'block';
    bindResultActions(resultArea, 'child');
  });

  // عملکرد دکمه‌های اکشن (Share, PDF, Image)
  function bindResultActions(area, mode) {
    // اشتراک‌گذاری
    let shareBtn = area.querySelector('.pl-bmi-share');
    if(shareBtn) {
    shareBtn.addEventListener('click', function(){
        // خروجی تمیز فقط از قسمت نمایش نتیجه
        let txt = '';
        // فقط متن مورد نظر را جمع کن (می‌تونی برحسب نیاز بهتر هم struct کنی)
        let bmiBox = area.querySelector('.pl-bmi-bmi-box');
        let advice = area.querySelector('.pl-bmi-advice-box');
        let table = area.querySelector('.pl-bmi-table');
        if(bmiBox) txt += bmiBox.innerText + '\n';
        if(advice) txt += advice.innerText + '\n';
        if(table) txt += '\n' + table.innerText + '\n';
        // امضا (اختیاری)
        let sig = area.querySelector('.pl-bmi-signature');
        if(sig) txt += '\n' + sig.innerText;

        // متن قالب تمیز برای اشتراک‌گذاری
        let shareText =
        (plBmiStrings['bmi_calculator'] || '') + "\n\n" +
        txt.trim() + "\n\n" +
        (plBmiStrings['share_link'] || 'Result:') + ' ' + window.location.href;

        if (navigator.share) {
        navigator.share({
            title: plBmiStrings['bmi_calculator'],
            text: shareText,
            url: window.location.href
        });
        } else {
        window.prompt((plBmiStrings['copy_share']||'Copy to share:'), shareText);
        }
    });
    }
    // PDF
        let pdfBtn = area.querySelector('.pl-bmi-save-pdf');
    if (pdfBtn && typeof html2pdf !== 'undefined') {
    pdfBtn.addEventListener('click', function() {
        // یک کپی کامل از بخش نتیجه بگیر
        let clone = area.cloneNode(true);
        // دکمه‌های اکشن را از کپی حذف کن تا در PDF نباشد
        clone.querySelectorAll('.pl-bmi-actions').forEach(el => el.remove());
        // کپی را مخفی در body اضافه کن تا render شود (display:block)
        clone.style.position = 'absolute';
        clone.style.left = '-9999px';
        clone.style.display = 'block';
        document.body.appendChild(clone);

        // گرفتن PDF از کپی
        html2pdf().from(clone).set({
        margin: [10, 10, 10, 10],
        filename: 'bmi-result.pdf',
        html2canvas: { scale: 2 }
        }).save().then(() => {
        clone.remove();
        }).catch(() => {
        clone.remove();
        });
    });
    }
    // Image
    let imgBtn = area.querySelector('.pl-bmi-save-img');
    if(imgBtn && typeof html2canvas !== 'undefined'){
      imgBtn.addEventListener('click', function(){
        let box = area.cloneNode(true);
        // حذف دکمه‌ها از عکس
        box.querySelectorAll('.pl-bmi-actions').forEach(el=>el.parentNode.removeChild(el));
        document.body.appendChild(box); box.style.position='absolute'; box.style.left='-9999px';
        html2canvas(box).then(canvas=>{
          let link = document.createElement('a');
          link.download = 'bmi-result.png';
          link.href = canvas.toDataURL();
          link.click();
          box.remove();
        });
      });
    } else if(imgBtn) {
      imgBtn.addEventListener('click', function(){ alert(plBmiStrings['img_error']||'Unable to save image.'); });
    }
  }
});
