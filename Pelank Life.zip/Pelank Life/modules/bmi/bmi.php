<?php
// modules/bmi/bmi.php

class Pelank_BMI_Module {
    public function __construct() {
        add_shortcode('pelank_bmi', [$this, 'render_bmi_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function enqueue_assets() {
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'pelank_bmi')) {
            $module_url = plugin_dir_url(__FILE__);
            wp_enqueue_style('pelank-bmi-css', $module_url . 'bmi.css');

            // لود کتابخانه‌های pdf و canvas فقط وقتی شورتکد وجود دارد
            wp_enqueue_script(
                'pelank-html2canvas',
                'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js',
                [],
                null,
                true
            );
            wp_enqueue_script(
                'pelank-html2pdf',
                'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js',
                ['pelank-html2canvas'],
                null,
                true
            );
            wp_enqueue_script(
                'pelank-bmi-js',
                $module_url . 'bmi.js',
                ['pelank-html2canvas', 'pelank-html2pdf'],
                null,
                true
            );

            // زبان پیش‌فرض انگلیسی (اگر فارسی نبود)
            $locale = get_locale();
            if (!file_exists(__DIR__ . "/lang/{$locale}.php")) {
                $locale = 'en_US';
            }
            $strings = include(__DIR__ . "/lang/{$locale}.php");

            // فقط کلیدهای معتبر (و نه هیچ متن فارسی) به JS
            wp_localize_script('pelank-bmi-js', 'PelankBmiStrings', $strings);
        }
    }

    public function render_bmi_shortcode($atts) {
        ob_start();
        include(__DIR__ . '/bmi-view.php');
        return ob_get_clean();
    }
}

new Pelank_BMI_Module();
