<?php
return [
    // Heading & description
    'bmi_calculator'   => 'BMI (Body Mass Index) Calculator',
    'bmi_description'  => 'The most advanced and scientific BMI calculator',

    // Tabs
    'tab_adult'        => 'Adult',
    'tab_child'        => 'Child/Teen',

    // Form
    'weight'           => 'Weight',
    'height'           => 'Height',
    'age'              => 'Age',
    'gender'           => 'Gender',
    'male'             => 'Male',
    'female'           => 'Female',
    'unit_kg'          => 'kg',
    'unit_lb'          => 'lb',
    'unit_cm'          => 'cm',
    'unit_in'          => 'inch',
    'calculate'        => 'Calculate',
    'reset'            => 'Reset',

    // Result / categories
    'your_bmi'         => 'Your BMI',
    'bmi_value'        => 'BMI value',
    'category'         => 'Category',
    'percentile'       => 'Percentile',
    'underweight'      => 'Underweight',
    'normal'           => 'Normal weight',
    'overweight'       => 'Overweight',
    'obesity_1'        => 'Obesity (Class 1)',
    'obesity_2'        => 'Obesity (Class 2)',
    'obesity_3'        => 'Extreme obesity',
    'your_decile'      => 'Your classification',
    'bmi_table_note'   => 'Based on WHO BMI categories',
    'bmi_child_note'   => 'Percentile table is based on CDC growth charts.',
    'see_growth_chart' => 'See CDC growth chart',

    // Percentile labels (child/teen)
    'p_below5'   => 'Very underweight',
    'p_5to85'    => 'Healthy weight',
    'p_85to95'   => 'At risk of overweight',
    'p_above95'  => 'Obese',

    // Actions
    'share'      => 'Share result',
    'save_pdf'   => 'Save as PDF',
    'save_img'   => 'Save as image',
    'copy_share' => 'Copy and share:',
    'share_link' => 'Result:',

    // Signature
    'signature'  => 'Developed by Pelank Life © – Scientific research: Mohsen Taheri',

    // Advice/advisory
    'advice_under'        => 'Your weight is below the healthy range. Consider consulting a healthcare professional for nutrition and health advice.',
    'advice_normal'       => 'Your weight is in the healthy range. Keep up the healthy diet and exercise!',
    'advice_over'         => 'You are slightly overweight. It\'s recommended to improve your diet and increase activity.',
    'advice_obese'        => 'You are in the obesity range. Medical consultation and lifestyle change are strongly recommended.',
    'warning_critical'    => 'Warning: Obesity can seriously endanger your health.',
    'advice_child_normal' => 'The BMI is within the healthy percentile for this age and gender.',
    'advice_child_other'  => 'This BMI is outside the healthy percentile. Please consult a pediatrician.',

    // Error & warning
    'invalid_input' => 'Invalid input. Please check your numbers.',
    'pdf_error'     => 'Unable to generate PDF. Please check your browser.',
    'img_error'     => 'Unable to save image. Please check your browser.',
];
