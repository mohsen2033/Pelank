<?php
return [
    // Heading & description
    'bmi_calculator'   => 'محاسبه شاخص توده بدنی BMI',
    'bmi_description'  => 'پیشرفته‌ترین و علمی‌ترین ماشین حساب محاسبه BMI',

    // Tabs
    'tab_adult'        => 'بزرگسال',
    'tab_child'        => 'کودک/نوجوان',

    // Form
    'weight'           => 'وزن',
    'height'           => 'قد',
    'age'              => 'سن',
    'gender'           => 'جنسیت',
    'male'             => 'پسر',
    'female'           => 'دختر',
    'unit_kg'          => 'کیلوگرم',
    'unit_lb'          => 'پوند',
    'unit_cm'          => 'سانتی‌متر',
    'unit_in'          => 'اینچ',
    'calculate'        => 'محاسبه',
    'reset'            => 'پاک‌کردن',

    // Result / categories
    'your_bmi'         => 'شاخص توده بدنی شما',
    'bmi_value'        => 'مقدار BMI',
    'category'         => 'دسته‌بندی',
    'percentile'       => 'صدک',
    'underweight'      => 'کم‌وزن',
    'normal'           => 'وزن نرمال',
    'overweight'       => 'اضافه وزن',
    'obesity_1'        => 'چاقی (درجه ۱)',
    'obesity_2'        => 'چاقی (درجه ۲)',
    'obesity_3'        => 'چاقی شدید',
    'your_decile'      => 'دسته‌بندی شما',
    'bmi_table_note'   => 'بر اساس جدول سازمان جهانی بهداشت (WHO)',
    'bmi_child_note'   => 'جدول صدک براساس نمودار رشد CDC است.',
    'see_growth_chart' => 'مشاهده نمودار رشد CDC',

    // Percentile labels (child/teen)
    'p_below5'   => 'خیلی کم وزن',
    'p_5to85'    => 'وزن سالم',
    'p_85to95'   => 'در معرض اضافه وزن',
    'p_above95'  => 'چاق',

    // Actions
    'share'      => 'اشتراک‌گذاری نتیجه',
    'save_pdf'   => 'ذخیره PDF',
    'save_img'   => 'ذخیره تصویر',
    'copy_share' => 'برای اشتراک کپی کنید:',
    'share_link' => 'لینک نتیجه:',

    // Signature
    'signature'  => 'توسعه یافته توسط پلانک لایف © – پژوهش علمی: Mohsen Taheri',

    // Advice/advisory
    'advice_under'        => 'وزن شما زیر محدوده سالم است. توصیه می‌شود با یک متخصص تغذیه یا پزشک مشورت کنید.',
    'advice_normal'       => 'وزن شما در محدوده سالم قرار دارد. تحرک و تغذیه سالم را ادامه دهید!',
    'advice_over'         => 'کمی اضافه وزن دارید. بهتر است تغذیه و فعالیت بدنی خود را بهبود دهید.',
    'advice_obese'        => 'شما در محدوده چاقی قرار دارید. مشاوره پزشکی و تغییر سبک زندگی بسیار توصیه می‌شود.',
    'warning_critical'    => 'هشدار: چاقی می‌تواند سلامت شما را جدی به خطر بیندازد.',
    'advice_child_normal' => 'BMI در صدک سالم برای این سن و جنسیت است.',
    'advice_child_other'  => 'این BMI خارج از محدوده سالم است. لطفاً با پزشک کودک مشورت کنید.',

    // Error & warning
    'invalid_input' => 'ورودی نامعتبر. لطفاً اعداد را بررسی کنید.',
    'pdf_error'     => 'امکان ساخت PDF وجود ندارد. لطفاً مرورگر خود را بررسی کنید.',
    'img_error'     => 'امکان ذخیره تصویر وجود ندارد. لطفاً مرورگر خود را بررسی کنید.',
];
