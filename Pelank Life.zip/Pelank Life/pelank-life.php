<?php
/*
Plugin Name: Pelank Life
Description: Modular Health Calculators (BMI, BMR, TDEE, ...)
Version: 1.0.0
Author: Pelank Team
Text Domain: pelank-life
Domain Path: /languages
*/

// Prevent direct access
if (!defined('ABSPATH')) exit;

define('PELANK_LIFE_PATH', plugin_dir_path(__FILE__));
define('PELANK_LIFE_URL', plugin_dir_url(__FILE__));

// Autoload modules
function pelank_life_load_modules() {
    $modules_dir = PELANK_LIFE_PATH . 'modules/';
    if (!is_dir($modules_dir)) return;

    foreach (glob($modules_dir . '*/', GLOB_ONLYDIR) as $module_dir) {
        $main_file = $module_dir . basename($module_dir) . '.php';
        if (file_exists($main_file)) {
            require_once $main_file;
        }
    }
}
add_action('plugins_loaded', 'pelank_life_load_modules');

// Load admin settings page
if (is_admin()) {
    require_once PELANK_LIFE_PATH . 'admin/settings-page.php';
}

// Load plugin text domain for translations
function pelank_life_load_textdomain() {
    load_plugin_textdomain('pelank-life', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'pelank_life_load_textdomain');
